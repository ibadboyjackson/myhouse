pholder Plugin
==============

* cross browser place holder plugin for jquery *

Plugin options:

className: 'placeholder class name (default: wtmrk)',

pholdertext:'Default place holder'


default placeholder text can be set in 'placeholder' attribute.
